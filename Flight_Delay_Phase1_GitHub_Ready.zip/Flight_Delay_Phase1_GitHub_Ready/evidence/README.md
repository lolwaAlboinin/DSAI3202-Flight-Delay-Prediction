# Evidence guide

Screenshots are intentionally NOT included in this starter zip because portal screenshots may contain personal account names or sensitive workspace information. Before pushing, redact sensitive data and add the applicable screenshots using the filenames below.

Recommended evidence:

- `raw_manifest_verification.png` — 12/12 hash validation and preserved source objects
- `safe_ingestion_rerun.png` — repeat ingestion leaves original objects unchanged
- `accepted_rejected_counts.png` — 7,001,619 total / 6,879,484 accepted / 122,135 rejected
- `duplicate_checks.png` — zero exact and flight-key duplicates
- `quality_failure_separate_input.png` — **still to demonstrate** full quality failure with a separate test input (the current 100/60 unit check is not sufficient)
- `eda_delay_distribution.png`, `eda_airlines.png`, `eda_hourly.png`
- `unity_catalog_lineage.png` — upstream/downstream lineage evidence
- `production_job_succeeded.png` — successful run and outputs
- `production_v2_catalog.png` — registered v2 tables and counts
- `production_v2_verification.png` — v2 checks passing
- `resource_measurement.png` — job duration/compute setting

Link screenshots from the README after adding them. Keep originals in your private evidence folder.
