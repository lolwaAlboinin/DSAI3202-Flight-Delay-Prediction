# Phase 1 Submission Checklist — based on official DSAI3202 Project Phase 1 v2 rubric

## Confirmed implemented from code and screenshots
- [x] Unique public BTS flight dataset, 2025 monthly files, >1 GB uncompressed
- [x] 12 monthly CSV files, batch ingestion, original ZIPs in versioned Azure raw path
- [x] Real row accounting and 90% quality threshold
- [x] Duplicate inspection and target-leakage controls
- [x] Processed and curated Parquet output, including versioned v2 production output
- [x] Databricks production job completed successfully (November 7, 2026)
- [x] EDA summary and charts based on full accepted population
- [x] v1/v2 Unity Catalog tables, verification and available lineage view
- [x] 13-column model-ready dataset (12 input/metadata fields + target)

## Still requires action/evidence before declaring submission complete
- [ ] Add the actual `safe_ingestion.ps1` and `manifest.csv` (or document exact regeneration commands and link manifest stored in Azure); current package does not contain these files
- [ ] Show an actual safe rerun with evidence and unchanged hash/identity of original preserved input
- [ ] Demonstrate controlled publication failure **with a separate bad test input**, not merely hard-coded `enforce_quality_gate(100,60)` unit call; document that no production output was overwritten
- [ ] Document missing-value patterns/rejection reasons and relevant outliers/correlations/data risks, not only class/airline/hour distributions
- [ ] Provide feature data dictionary: definitions, types, source fields, prediction-time availability and leakage risk
- [ ] Confirm actual source schema, keys, assumptions, raw→processed→curated lineage diagram
- [ ] Add evidence screenshots after reviewing/redacting user/account information
- [ ] Record a measured or estimated cost/performance optimization and compute cleanup procedure
- [ ] Supply exact runtime version and exported portal job config if available
- [ ] Ensure AI-use disclosure covers proposal, code, analysis and editing, including what was personally verified/changed
- [ ] Ensure topic/hypothesis revisions and use of Databricks Jobs instead of originally proposed Azure Data Factory are documented (and approved if required)
- [ ] Create repo, meaningful commits, give instructor access, submit repository URL plus final commit SHA on D2L

## Not required in Phase 1 unless separately instructed
- A trained Random Forest model, model accuracy or F1 results (hypothesis provides a baseline and Phase 2 plan)
- Azure ML model endpoint
- Managed feature store or Microsoft Purview

**Do not claim full marks or final completion until the remaining rubric evidence has been verified.**
